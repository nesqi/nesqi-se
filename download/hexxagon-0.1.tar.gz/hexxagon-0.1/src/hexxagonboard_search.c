/*
 * Hexxagon board game.
 * Copyright (C) 2001 Erik Jonsson.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Email erik@nesqi.homeip.net
 * 
 * */

#include "hexxagonboard.h"
#include <sys/timeb.h>
#include <iostream.h>

#ifdef GUI
void update_gui();
char counter = 0;
#endif

double getTime()
{
	struct timeb tb;
	
	ftime(&tb);
	return tb.time + (double) tb.millitm / 1000;
}

int alphaBeta(HexxagonBoard board, int level, int alpha, int beta)
{
	HexxagonBoard *moved = 0;
	int best = -INFINITY;
	int value;
	int foundmove = 0;

#ifdef GUI
	if(counter++ == 0) update_gui();
#endif

	if(!level)
		return board.evaluate();

	board.resetMoveIterator();

	while((moved = board.applyNextMove()) && best < beta)
	{
		foundmove = 1;

		if(best > alpha)
			alpha = best;

		value = -alphaBeta(*moved, level - 1, -beta, -alpha);

		delete moved;

		if(value > best)
			best = value;
	}     

	if(moved)
		delete moved;

	if(!foundmove)
		return board.evaluate();

	return best;
}

HexxagonBoard *HexxagonBoard::findBestMove(int depth)
{
	HexxagonBoard *moved = 0;
	HexxagonBoard *retboard = 0;
	int best = -INFINITY;
	int alpha = -INFINITY;
	int beta = INFINITY;
	int value;
	double t = getTime();

	if(!depth)
		return 0;

	this->resetMoveIterator();

	while((moved = this->applyNextMove()) && best < beta)
	{
		if(best > alpha)
			alpha = best;

		value = -alphaBeta(*moved, depth - 1, -beta, -alpha);

		if(value > best)
		{
			best = value;

			if(!retboard)
				retboard = new HexxagonBoard();

			*retboard = *moved;
		}

		delete moved;
	}     

	if(moved)
		delete moved;

	cout << "Move computed in " << getTime() - t << " seconds.\n";

	return retboard;
}
