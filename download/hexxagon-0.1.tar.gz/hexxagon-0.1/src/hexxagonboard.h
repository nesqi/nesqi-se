/*
 * Hexxagon board game.
 * Copyright (C) 2001 Erik Jonsson.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Email erik@nesqi.homeip.net
 * 
 * */

#ifndef _HEXXAGONBOARD_H
#define _HEXXAGONBOARD_H

#include "bitboard64.h"

enum
{
	WIN = 20000,
	INFINITY = 32000
};

class HexxagonBoard
{
 public:

	HexxagonBoard(void);
	HexxagonBoard(const HexxagonBoard &copy);

	void init(void);
	void displayPlayBoard(void);

	int applyMove(int from, int to);
	void resetMoveIterator(void) {position_iterator = 0; type_iterator = 0;};
	HexxagonBoard *applyNextMove(void);
	
	int getBitFromPos(int x, int y);

	int evaluate(void);
	int countBricks(int player);
	HexxagonBoard *findBestMove(int depth);

	HexxagonBoard operator=(const HexxagonBoard &right);

	BitBoard64 getBitBoardColor() {return color;};
	BitBoard64 getBitBoardBoard() {return board;};

 private:

	int turn;
	int position_iterator;
	int type_iterator;

	BitBoard64 board;
	BitBoard64 color;
};

#endif
