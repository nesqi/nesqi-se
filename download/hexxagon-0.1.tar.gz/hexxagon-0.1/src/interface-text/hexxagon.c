/*
 * Hexxagon board game.
 * Copyright (C) 2001 Erik Jonsson.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Email erik@nesqi.homeip.net
 * 
 * */

#include <stdio.h>
#include <stdlib.h>
#include <hexxagonboard.h>

int main(int argc, char *argv[])
{
	if(argc != 3 
	   || !(atoi(argv[1]) > 0 && atoi(argv[1]) <= 8) 
	   || !(*argv[2] == 'c' || *argv[2] == 'h'))
	{
		printf("%s%s%s%s",
			   "Hexxagon 0.4\nby Erik Jonsson.\n",
			   "Usage: hexxagon depth mode\n",
			   "  depth: The depth for searches. Valid depths are 1-8.\n",
			   "  mode : 'c' for computer v. computer. 'h' for human vs. computer.\n");	
		return 1;	
	}
	
	HexxagonBoard board;
    HexxagonBoard *tmp;

    board.init();
    board.displayPlayBoard();

    board.resetMoveIterator();
	
	while((tmp = board.findBestMove(atoi(argv[1]))))
	{
		board = *tmp;
		board.displayPlayBoard();
		delete tmp;

		if(*argv[2] == 'h')
		{
		    char move[6];
			do
			{
				printf("\rEnter a move (eg. a4a4 for clone and b5d6 for jump): ");
				fflush(stdout);
				fgets(move, 6, stdin);
				fflush(stdin);
			} while(!((move[0] >= 'a' && move[0] <= 'i')
					   && (move[2] >= 'a' && move[2] <= 'i')
					   && (move[1] >= '1' && move[1] <= '9')
					   && (move[3] >= '1' && move[3] <= '9')) && !(*move == '\n'));
			
			/* Make the computer move for you */
			if(*move == '\n')
			{
				if(!(tmp = board.findBestMove(atoi(argv[1]))))
				   break;

				board = *tmp;
				delete tmp;
			}
			else /* Apply the given move (OBS ! There is no error checking.) */
			{
				board.applyMove(board.getBitFromPos(move[0] - 'a' + 1, 
													move[1] - '1' + 1),
								board.getBitFromPos(move[2] - 'a' + 1, 
													move[3] - '1' + 1));
			}

			board.displayPlayBoard();
		}
	} 

	return 0;
}

