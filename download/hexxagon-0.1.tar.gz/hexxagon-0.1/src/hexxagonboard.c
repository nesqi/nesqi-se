/*
 * Hexxagon board game.
 * Copyright (C) 2001 Erik Jonsson.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * Email erik@nesqi.homeip.net
 * 
 * */

#include "hexxagonboard.h"
#include <iostream.h>

BitBoard64 *clone_lookups = 0; 
BitBoard64 *jump_lookups = 0; 

HexxagonBoard::HexxagonBoard(void)
{
	if(!clone_lookups)
	{
		clone_lookups = new BitBoard64[61];

		int no = 0;

		// clone 
		for(int y = 1; y <= 9; y++)
		{
			for(int x = 1; x <= 9; x++)
			{
				int out = 0;
				
				if(x > 0 && x < 10 && y > 0 && y < 10)
				{
					if(y < 5)
						if(x > (9 - (5 - y)))
							out = 1;
					
					if(y > 5)
						if(x <= (y - 5))
							out = 1;
				}
				
				if(!out)
				{
					clone_lookups[no].setBit(getBitFromPos(x-1, y-1));
					clone_lookups[no].setBit(getBitFromPos(x  , y-1));
					clone_lookups[no].setBit(getBitFromPos(x-1, y  ));
					clone_lookups[no].setBit(getBitFromPos(x+1, y  ));
					clone_lookups[no].setBit(getBitFromPos(x  , y+1));
					clone_lookups[no].setBit(getBitFromPos(x+1, y+1));
					no++;
				}
			} 
		}
	}

	if(!jump_lookups)
	{
		jump_lookups = new BitBoard64[61];

		int no = 0;
		// jump
		for(int y = 1; y <= 9; y++)
		{
			for(int x = 1; x <= 9; x++)
			{
				int out = 0;
				
				if(x > 0 && x < 10 && y > 0 && y < 10)
				{
					if(y < 5)
						if(x > (9 - (5 - y)))
							out = 1;
					
					if(y > 5)
						if(x <= (y - 5))
							out = 1;
				}
				
				if(!out)
				{
					jump_lookups[no].setBit(getBitFromPos(x-2, y-2));
					jump_lookups[no].setBit(getBitFromPos(x-1, y-2));
					jump_lookups[no].setBit(getBitFromPos(  x, y-2));
					jump_lookups[no].setBit(getBitFromPos(x-2, y-1));
					jump_lookups[no].setBit(getBitFromPos(x+1, y-1));
					jump_lookups[no].setBit(getBitFromPos(x-2, y  ));
					jump_lookups[no].setBit(getBitFromPos(x+2, y  ));
					jump_lookups[no].setBit(getBitFromPos(x-1, y+1));
					jump_lookups[no].setBit(getBitFromPos(x+2, y+1));
					jump_lookups[no].setBit(getBitFromPos(x  , y+2));
					jump_lookups[no].setBit(getBitFromPos(x+1, y+2));
					jump_lookups[no].setBit(getBitFromPos(x+2, y+2));
					no++;
				}
			}
		}
	}
}

HexxagonBoard::HexxagonBoard(const HexxagonBoard &copy)
{
	turn = copy.turn;
	board = copy.board;
	color = copy.color;
}

HexxagonBoard HexxagonBoard::operator=(const HexxagonBoard &right)
{
	color = right.color;
	board = right.board;
	turn = right.turn;
	return *this;
}

void HexxagonBoard::init(void)
{
	turn = 1;

	board.setBit( 0); color.setBit( 0);
    board.setBit(34); color.setBit(34);
	board.setBit(56); color.setBit(56);
	board.setBit( 4);
	board.setBit(26);
	board.setBit(60);
}

int HexxagonBoard::getBitFromPos(int x, int y)
{
	int no;

	if(x > 0 && x < 10 && y > 0 && y < 10)
	{
		if(y < 5)
			if(x > (9 - (5 - y)))
				return -1;

		if(y > 5)
			if(x <= (y - 5))
				return -1;
	  
		no = x+y*9 - 10;
	  
		if(y > 1) no -= 4;
		if(y > 2) no -= 3;
		if(y > 3) no -= 2;
		if(y > 4) no -= 1;
		if(y > 5) no -= 1;
		if(y > 6) no -= 2;
		if(y > 7) no -= 3;
		if(y > 8) no -= 4;
	  
		return no;
	}

	return -1;
}

int HexxagonBoard::countBricks(int player)
{
	int good = 0, bad = 0;

	for(int i = 0; i < 61; i++)
	{
		if(board.getBit(i))
		{
			if(color.getBit(i))
				good++;
			else
				bad++;
		}
	}

	if(player == 0)
		return good - bad;
	else if(player == 1)
		return good;
	else if(player == 2)
		return bad;
	
	return 0;
}

int HexxagonBoard::evaluate(void)
{
	BitBoard64 mine;
	BitBoard64 his;
	BitBoard64 free;
	int good = 0; 
	int bad = 0;
	int count = 0;
	int score = 0;

	free = ~board;
	mine = board & color;
	his  = board & ~color;

	for(int i = 0; i < 61; i++)
	{
		if(board.getBit(i))
		{
			count++;
			if(color.getBit(i))
				good++;
			else
				bad++;
		}
	}
    
	score += 2 * (good - bad);
	
	if(good == 0 || bad == 0 || count == 61) /* Game is over... */
	{
		if(good == 0)
			score -= WIN;

		if(bad == 0)
			score += WIN;

		if(count == 61)
		{
			if(good > bad)
				score += WIN;
			
			if(good <= bad)
				score -= WIN;
		}
	}
/*	else
	{
		HexxagonBoard hexboard(*this);
		HexxagonBoard *move;
		int before;
		
		hexboard.resetMoveIterator();
		before = -hexboard.countBricks(0);
		
		while((move = hexboard.applyNextMove()))
		{
			int r;

			r = move->countBricks(0);

			if(r > before)
				score += r - before;
			
			delete move;
		}
	}
*/
	return score;
}

int HexxagonBoard::applyMove(int from, int to)
{
	if(board.getBit(to))
		return -1;
	
	board.setBit(to);
	color.setBit(to);

	color = color | clone_lookups[to];

	if(from != to) // jump.
		board.unSetBit(from);
	
	color = ~color;
	turn = !turn;

	return 0;
}

HexxagonBoard *HexxagonBoard::applyNextMove(void)
{
	for(; position_iterator < 61; position_iterator++)
	{
		if(!board.getBit(position_iterator)) // found place to clone/jump.
		{
			if((type_iterator == 0) && 
			   (color.operator&((board.operator&(clone_lookups[position_iterator]))))) // clone !
			{
				HexxagonBoard *moved = new HexxagonBoard(*this);

				moved->applyMove(position_iterator, position_iterator);

				type_iterator = 1;

				return moved;
			}
			
			BitBoard64 moves;
			if((moves = ((board & jump_lookups[position_iterator]) & color))) // Jump.
			{
				if(type_iterator == 0)
					type_iterator = 1;

				for(; type_iterator <= 61; type_iterator++)
				{
					if(moves.getBit(type_iterator - 1))
					{
						HexxagonBoard *moved = new HexxagonBoard(*this);
						
						moved->applyMove(type_iterator - 1, position_iterator);

						type_iterator++;

						return moved;
					}
				}
			}
		}

		type_iterator = 0;
	}

	return 0;
}

void HexxagonBoard::displayPlayBoard(void)
{
	BitBoard64 c(color);

	if(!turn)
		c = ~c;

	cout << "         A B C D E F G H I\n";
	cout << "        / / / / / / / / /\n";

	for(int y = 1; y < 10; y++)
	{
		cout << y << "- ";

		if(y < 5)
		{
			for(int off = 0; off < (5 - y); off++)
				cout << " ";
		}

		for(int x = 1; x < 10; x++)
		{
			int no;

			if((no = getBitFromPos(x, y)) == -1)
				cout << " ";
			else 
			{
				if(board.getBit(no))
				{
					if(c.getBit(getBitFromPos(x, y)))
						cout << "x ";
					else
						cout << "o ";
				} else
					cout << ". ";
			}
		}
		cout << "\n";
	}

	cout << "Score to " << (turn ? "x " : "o ") << evaluate() << "\n";
	cout << "\n";
}
